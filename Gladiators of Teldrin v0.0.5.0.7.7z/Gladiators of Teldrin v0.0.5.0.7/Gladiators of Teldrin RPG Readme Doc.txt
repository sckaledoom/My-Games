Installation and Playing:
    Just unzip the archive into any directory, make sure you have python installed and type this command into your command prompt:

   Windows:
    "C:\> %Insert directory of python and, usually C:\python27 or C:\python32%\python.exe %Installation directory%\Gladiators of Teldrin.py"
   Linux (Ubuntu):
    "~ $ python "Gladiators of Teldrin.py"" in installation directory.
    Without binding quotes.

Stats:
    Class:
        Determines your general aptitudes at the beginning and leveling rate.
            Fighter: Generic bash-and-whacker. Gets 1d10 HP/level, starts with 50 base health. 
            Rogue: Speedy fighter. Gets 1d6 HP/level, starts with 45 base HP.
            Mage: Not much of a fighter, weak and slow, but has the largest mana pool. Starts with 20 base health, gains 1d4 per level.
            Gladiator: Relatively all-around, starts with 35 HP and small mana pool, gains 1d8 HP/level

    Abilities:
        Determines many modifiers.
            Strength: Gives a bonus on each damage roll
            Dexterity: Gives a bonus on to-hit rolls, and bonus hits per attack.
            Endurance: Gives bonus health

    XP:
        You gain an amount for each combat you participate in. Each class has an exponentially increasing XP value needed for each level up.

Level up:
    Gives a 33% chance for each individual Ability to increase by one. Your to-hit chance also icreases by an amount dependent on your class, and this is when your HP increases occur. 

Gladiator Hierarchy (Not finished):
    As a novice, you must climb the proverbial ladder. At the end, you will have earned enough money to buy your freedom. Will be incrementally implemented in each succeeding version.
