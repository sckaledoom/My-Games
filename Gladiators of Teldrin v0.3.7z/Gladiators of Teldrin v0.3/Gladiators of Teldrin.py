from sys import argv
import random
print "Welcome to Gladiators of Teldrin"
print "(S)tart"
print "(C)lose"
def ShowStats():
    print "Would you like to see your stats? (y/n)"
    stats= raw_input()
    if stats == "y":
            print "HP =" + str(maxHP)
            print "mana =" + str(maxmana)
            print "Endurance =" + str(End)
            print "Strength =" + str(Str)
            print "Dexterity =" + str(Dex)
            print "Intellect =" + str(Intellect)
def UndoSpells():
    global waActive
    global saActive
    global enemywaActive
    global enemysaActive
    global sdActive
    global enemysdActive
    global enemydmgMod
    global dmgMod
    dmgMod = 0
    enemydmgMod = 0
    sdActive = 0
    enemysdActive = 0
    waActive = 0
    saActive = 0
    enemywaActive = 0
    enemysaActive = 0
    HP = maxHP
    mana = maxmana
    damage = 0
def Combat():
        global end
        global fight
        global enemydmgMod
        global EnemyHP
        global enemyMana
        global critChance
        global damage
        global HP
        global mana
        global dmgMod
        global sdActive
        global enemysdActive
        global waActive
        global saActive
        global AC
        global enemyStr
        global enemyDex
        global enemyTHAC0
        global enemyAC
        global maxHP
        end = 0
        print "HP= " +str(HP)
        print "Mana= " +str(mana)
        print "Do you:"
        print "(A)ttack"
        print "(B)lock"
        print "(C)ast"
        print "(R)un away"
        totalDamage = 0
        action = raw_input()
        if action == "r":
            print "You have run away, forfeiting the match and angering your trainers. Still, the punishment you will recieve will be far less than what you would see in the aferlife"
            fight +=1
            enemydamage = 0
            damage = 0
        elif action == "a":
            toHit = THAC0 - (random.randint(1,20) + int(Dex/5))
            critical = random.randint(1,100)
            if critical == critChance:
                dmgMod = 3
            if sdActive == 1:
                if toHit <= enemyAC:
                    damage = (random.randint(2,16) + int(Str/5) * enemydmgMod) * int(Dex/5)
                    print "You hit for " + str(damage) + " HP!"
                    enemydmgMod = 1
                    sdActive = 0
                    saActive = 0
                    waActive = 0
                else:
                    print "Even with the magic in your sword arm, you missed!"
                    damage = 0
            else:
                if toHit <= enemyAC:
                    damage = (int(Str/5) + random.randint(1,8) * enemydmgMod) * int(Dex/5)
                    enemydmgMod = 1
                    print "You hit for " + str(damage) + " HP!"
                else:
                    print "You missed!"
                    damage = 0
                    enemydmgMod = 1
        elif action == "b":
            dmgMod = dmgMod * .5
            damage = 0
            print "You are blocking"
        elif action == "c":
            print "Which spell?"
            print "(M)agic Bullet"
            print "(S)word Dance"
            print "(W)eaken Armor"
            print "S(u)nder Weapons"
            spell = raw_input()
            if mana > 0:
                if spell == "m":
                    damage = random.randint(2,5) * Intellect
                    print "The magical weapon soars through the air and slams into your enemy for " + str(damage) + " HP!"
                    mana = mana-1
                    waActive = 0
                    saActive = 0
                elif spell == "s":
                    sdActive = 1
                    print "You feel the magical energies suffuse your blades and sword arm."
                    mana = mana-1
                    damage = 0
                    saActive = 0
                    waActive = 0
                elif spell == "w":
                    waActive = 1
                    saActive = 0
                    if waActive == 1:
                        enemydmgMod = enemydmgMod * 3
                    damage = 0
                    print "You have weakened your enemy's armor for a round."
                    mana = mana -1
                elif spell == "u":
                    waActive = 0
                    saActive = 1
                    if saActive == 1:
                        dmgMod = dmgMod * .3
                    print "You have sundered your enemy's weapons"
                    damage = 0
            else:
                print "You don't have any mana"
        EnemyHP = EnemyHP - damage
        if EnemyHP <= 0:
            fight += 1
            HP = maxHP
            mana = maxmana
            print "The enemy falls to the ground. Your sword point hovers above his throat. You look up at the master of the arena. He hold his thumb down. Everyone cheers as you slide the sword point into his throat."
            print "You go back to the barracks, the thrill from your fight still coursing through your veins."
            IncreaseXP()
            Levelup()
            print "You are awakened by the sound of your trainer's voice telling you to go to the chariot"
            enemysdActive = 0
        elif enemyMana > 0:
            enemyChoice = random.randint (1,3)
            if enemyChoice == 1:
                toHit =enemyTHAC0 - (random.randint (1,20) + int(enemyDex/5))
                if enemysdActive == 1:
                    if toHit <= AC:
                        damage = (int(enemyStr/5) + random.randint(2,16) * dmgMod) * int(enemyDex/5)
                        print "He hits you for " + str(damage) + " HP!"
                        dmgMod = 1
                        enemysdActive = 0
                        enemywaActive = 0
                        enemysaActive = 0
                    else:
                        print "Even with the magic in his sword arm, he missed!"
                        damage = 0
                        dmgMod = 1
                else:
                    if toHit >= 10:
                        damage = (int(enemyStr/5) + random.randint(1,8) * dmgMod) * int(enemyDex/5)
                        enemysaActive = 0 
                        enemywaActive = 0
                        print "He hits you for " + str(damage) + " HP!"
                    else:
                        print "He missed!"
                        damage = 0
                        enemysaActive = 0
                        enemywaActive = 0
            elif enemyChoice == 2:
                enemydmgMod = enemydmgMod * .5
                damage = 0
                enemysaActive = 0
                enemywaActive = 0
                print "He blocks!"
            elif enemyChoice == 3:
                spell = random.randint (1,4)
                if spell == 1:
                    damage = (random.randint (2,5)) * enemyIntellect
                    enemyMana = enemyMana - 1
                    enemysaActive = 0
                    enemywaActive = 0
                    print "He fires a Magic Bullet and it arcs through the air to hit you, dealing " + str(damage) + " HP in damage"
                elif spell == 2:
                    enemysdActive = 1
                    print "Magic suffuses the enemy's sword and arm."
                    enemysaActive = 0
                    enemywaActive = 0
                    damage = 0
                    enemyMana = enemyMana -1
                elif spell == 3:
                    enemywaActive = 1
                    if enemywaActive == 1:
                        dmgMod = dmgMod * 3
                    print "The opponent weakens your armor"
                    damage = 0
                    enemysaActive = 0
                    enemyMana = enemyMana - 1
                elif spell == 4:
                    enemysaActive = 1
                    enemywaActive = 0
                    if enemysaActive == 1:
                        enemydmgMod = enemydmgMod * .3
                    damage = 0
                    print "Your sword is sundered"
                    enemyMana = enemyMana -1
        else:
            enemyChoice = random.randint (1,3)
            if enemyChoice == 1 or 2:
                toHit = random.randint (1,20)
                if enemysdActive == 1:
                    if toHit >= 5:
                        damage = (int(enemyStr/5) + random.randint(2,16) * dmgMod) * (enemyDex/5)
                        print "He hits you for " + str(damage) + " HP!"
                        enemysdActive = 0
                        enemysaActive = 0
                        enemywaActive = 0
                    else:
                        print "Even with the magic in his sword arm, he missed!"
                        damage = 0
                        enemysdActive = 0
                        enemysaActive = 0
                        enemywaActive = 0
                else:
                    if toHit >= 10:
                        damage = (int(enemyStr/5) + random.randint(1,8) * dmgMod) * int(enemyDex/5)
                        enemysaActive = 0
                        enemywaActive = 0
                        print "He hits you for " + str(damage) + " HP!"
                    else:
                        print "He missed!"
                        damage = 0
                        enemysaActive = 0
                        enemywaActive = 0
            elif enemyChoice == 2:
                enemydmgMod = enemydmgMod * .5
                print "He blocks!"
                enemysaActive = 0
                enemywaActive = 0
                damage = 0
        HP = HP - int(damage)
        totalDamage = totalDamage + damage
        if HP<=0:
            print "Some are lucky enough to fight in the arena long enough to earn their freedom... Onlookers realize as you bleed out that you are not one."
            end = 1
        if end == 1:
            print "You have failed."
            exit()
            
def IncreaseXP():
    global XP
    global enemyXP
    XP = XP + enemyXP
    print "You gained " + str(enemyXP) + " XP"
def Levelup():
    global maxHP
    global THAC0
    global maxmana
    global critChance
    global Nextlvl
    global Str
    global Dex
    global End
    if XP >=Nextlvl:
        Nextlvl *=1.5
        print "You levelled up!"
        print "Your health increased"
        print "Your chance to hit went up!"
        strRoll = random.randint(1,100)
        endRoll = random.randint(1,100)
        dexRoll = random.randint(1,100)
        if strRoll <= 33:
            print "Your strength increased by 1"
            Str +=1
        if endRoll <= 33:
            print "Your endurance went up by 1"
            End +=1
        if dexRoll <= 33:
            print "Your dexterity increased by 1"
            Dex +=1
        if int(PCclass) == 1:
            maxHP = maxHP + random.randint(1,10) + int(End/5)
            THAC0 = THAC0 - 2
        elif int(PCclass) == 2:
            print "Your mana increased"
            maxHP = maxHP +random.randint(1,4) + int(End/5)
            maxmana = maxmana + random.randint(1,3)
            THAC0 = THAC0 - .25
        elif int(PCclass) == 3:
            maxHP += random.randint(1,6) + int(End/5)
            THAC0 += - .5
        elif int(PCclass) == 4:
            print "Your mana increased"            
            maxHP = maxHP + random.randint (1,8) + int(End/5)
            maxmana = maxmana + 1
            THAC0 = THAC0 - 1
        HP = maxHP
        print "HP = " + str(maxHP)
        print "Mana = " + str(maxmana)
        print "Strength = " + str(Str)
        print "Endurance = " + str(End)
        print "Dexterity = " + str(Dex)
response=raw_input()
if response == "s":
    print "Create your character"
    print "Choose a class:"
    print "1) Fighter"
    print "2) Mage"
    print "3) Rogue"
    print "4) Gladiator"
    PCclass=raw_input()
    if int(PCclass) == 1:
        End = 14
        maxHP = 50 + int(End/5)
        Str = 15
        Dex = 10
        critChance = 5
        AC = 3
        maxmana = 0
        THAC0 = 17
        XP = 0
        Intellect = 1
        Nextlvl = 1000
    if int(PCclass) == 2:
        End = 10
        maxHP = 20 + int(End/5)
        Str = 5
        Dex = 5
        maxmana = 25
        THAC0 = 20
        Intellect = 2
        AC = 10
        critChance = 0
        XP = 0
        Nextlvl = 500
    if int(PCclass) == 3:
        Str = 10
        Dex = 15
        End = 13
        AC = 5
        Intellect = 1
        critChance = 15
        maxHP = 45 + int(End/5)
        maxmana = 0
        THAC0 = 19
        XP = 0
        Nextlvl = 500
    if int(PCclass) == 4:
        Str = 15
        Dex = 8
        End = 15
        maxHP = 35 + int(End/5)
        critChance = 2
        maxmana = 2
        AC = 4
        THAC0 = 18
        Intellect = 1
        XP = 0
        Nextlvl = 750
    print "You are a gladiator in a massive arena, a participant in a bloody spectacle for millions to see."
    print "You are facing your first enemy, also a novice in the art of combat."
    HP = maxHP
    mana = maxmana
    EnemyHP = 35
    enemyMana = 2
    fight = 0
    enemydmgMod = 1
    dmgMod = 1
    sdActive = 0
    enemysdActive = 0
    enemyDex = 7
    enemyStr = 15
    enemyAC = 6
    enemyTHAC0 = 18
    enemyXP = 500
    ShowStats()
    enemyIntellect = 1
    while fight==0:
        Combat()
    EnemyHP = 57
    enemyStr = 13
    enemyDex = 19
    enemyTHAC0 = 17
    enemyMana = 0
    enemyAC = 7
    enemyIntellect = 1
    enemyXP = 1000
    UndoSpells()
    ShowStats()
    HP = maxHP
    print "You are told that your next opponent is to be Galsin the Lightning Step, an exceptionally fast person who it is told that he can attack three times in the amount of time that most people can only hit once or twice."
    while fight == 1:
        Combat()
    EnemyHP = 40
    enemyStr = 9
    enemyDex = 10
    enemyTHAC0 = 19
    enemyMana = 30
    enemyAC = 8
    enemyIntellect = 2
    enemyXP = 1050
    UndoSpells()
    ShowStats()
    HP = maxHP
    print "Your master leans in and says, \"You are skilled. That is why I trust you with the next fight. Your next opponent is a great mage named Haros. He is powerful and experienced. \" He gives you a comforting pat on the shoulder, \"I believe that you have this fight, though.\" "
    while fight == 2:
        Combat()
    EnemyHP = 75
    enemyIntellect = 1
    enemyMana = 0
    enemyStr = 25
    enemyDex = 14
    enemyTHAC0 = 15
    enemyAC = 3
    enemyXP = 2000
    UndoSpells()
    ShowStats()
    HP = maxHP
    print "The other gladiators performing today look at you as one would look at a fresh corpse. One of them tells you that your next opponent, and likely last, is the brute Garmesh the Giant. With strength superhuman, and speed to back it up, he has smashed all of the previous opponents he had fought. He is favored to win seventeen to one.Your task this day is to prove them wrong."
    while fight == 3:
        Combat()
    EnemyHP = 90
    enemyIntellect = 2
    enemyMana = 10
    enemyStr = 19
    enemyDex = 16
    enemyTHAC0 = 16
    enemyAC = 4
    enemyXP = 1500
    UndoSpells()
    ShowStats()
    HP = maxHP
    print "Your master leans in and says, \"That victory against Garmesh has caught wind and made our school famous. Now, you are recieving a large amount of requests. I did accept this one, because it seems like it shouldn't be TOO hard\" He smiles a crinkled, though genuine smile."
    while fight == 4:
        Combat()
    print "Goodbye"